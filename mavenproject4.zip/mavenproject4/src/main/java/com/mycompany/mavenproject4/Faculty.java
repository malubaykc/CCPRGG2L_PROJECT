/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.mavenproject4;

/**
 *
 * @author khyle
 */
import java.io.*;

public class Faculty {
    public void encode(){
String filename = "courses.txt";
boolean continueAddingCourses = true;

try {
    try (FileWriter writer = new FileWriter("C:\\Users\\khyle\\OneDrive\\Documents\\courses.txt")) {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        
        while (continueAddingCourses) {
            // requires the admin to enter the name of the course 
            System.out.print("Enter the name of the course you want to encode (or 'quit' to exit): ");
            String courseName = reader.readLine();
            
            if (courseName.equalsIgnoreCase("quit")) {
                continueAddingCourses = false;
                break;
            }
            
            System.out.print("Enter the course code: ");
            String courseCode = reader.readLine();
                        
            System.out.print("Enter the semester: ");
            int semester = Integer.parseInt(reader.readLine());
            
            // writes the course encoded by the admin to course.txt
            String encodedCourse = encodeCourse(courseName, courseCode, semester);
            writer.write(encodedCourse + "\n");
            
            System.out.println("Course added successfully.");                   
        }
    }
    System.out.println("The course was encoded to " + filename);
} catch (IOException e) {           
    System.out.println("An error occurred: " + e.getMessage());
}
    }
public static String encodeCourse(String courseName, String courseCode, int semester) {
    String encodedCourse = "";
    encodedCourse += courseName.charAt(0);
    encodedCourse += courseName.charAt(courseName.length() - 1);
    encodedCourse += courseCode.substring(2);
    encodedCourse += semester;
    return encodedCourse;
}
    }

